package com.demo.enablerbackendtool.service;

import java.util.List;
import com.demo.enablerbackendtool.model.Employee;

public interface EmployeeService {
    
    public Employee saveEmployee(Employee employee);
    
    public List<Employee> getAllEmployees(Boolean status);  
    
    public Employee getEmployeeById(Long id);  // Changed int to Long
    
    public void deleteEmployee(Long id);  // Changed int to Long
    
    public Employee updateEmployee(Long id, Employee employee);  // Changed int to Long
}
