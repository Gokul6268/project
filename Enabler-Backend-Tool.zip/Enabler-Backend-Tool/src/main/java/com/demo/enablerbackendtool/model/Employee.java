package com.demo.enablerbackendtool.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.Period;

@Entity
@Table(name = "employees")
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long Id;

    @Column(name = "Name", nullable = false)
    private String name;

    @Column(name = "Email", nullable = false)
    private String email;

    @Column(name = "Dob", nullable = false)
    private LocalDate dob;

    @Column(name = "Age", nullable = false)
    private Integer age;

    @Column(name = "Salary", nullable = false)
    private Double salary;

    @Column(name = "Status", nullable = false)
    private Boolean status;

    public Employee() {}

    public Employee(String name, String email, LocalDate dob, Double salary, Boolean status) {
        this.name = name;
        this.email = email;
        this.dob = dob;
        this.age = calculateAge(dob);
        this.salary = salary;
        this.status = status;
    }

    // Getters and setters...
    public Long getId() {
        return Id;
    }

    public void setId(Long Id) {
        this.Id = Id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public LocalDate getDob() {
        return dob;
    }

    public void setDob(LocalDate dob) {
        this.dob = dob;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public Double getSalary() {
        return salary;
    }

    public void setSalary(Double salary) {
        this.salary = salary;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    private Integer calculateAge(LocalDate dob) {
        return Period.between(dob, LocalDate.now()).getYears();
    }
}
