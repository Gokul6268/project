package com.demo.enablerbackendtool.repository;

import com.demo.enablerbackendtool.model.Employee;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {  // Changed Integer to Long
    List<Employee> findByStatus(Boolean status);
}

