package com.demo.enablerbackendtool.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.demo.enablerbackendtool.model.Employee;
import com.demo.enablerbackendtool.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Override
    public Employee saveEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    @Override
    public List<Employee> getAllEmployees(Boolean status) {
        if (status != null) {
            return employeeRepository.findByStatus(status);  // Filter by status if provided
        }
        return employeeRepository.findAll();
    }

    @Override
    public Employee getEmployeeById(Long id) {  // Changed int to Long
        return employeeRepository.findById(id).orElse(null);
    }

    @Override
    public void deleteEmployee(Long id) {  // Changed int to Long
        Optional<Employee> optionalEmployee = employeeRepository.findById(id);
        if (optionalEmployee.isPresent()) {
            employeeRepository.delete(optionalEmployee.get());
        } else {
            throw new RuntimeException("Employee not found with id: " + id);
        }
    }

    @Override
    public Employee updateEmployee(Long id, Employee employee) {  // Changed int to Long
        Optional<Employee> optionalEmployee = employeeRepository.findById(id);
        if (optionalEmployee.isPresent()) {
            Employee oldEmployee = optionalEmployee.get();
            employee.setId(oldEmployee.getId());  // Ensure ID is preserved
            return employeeRepository.save(employee);
        } else {
            throw new RuntimeException("Employee not found with id: " + id);
        }
    }
}
