package com.demo.enablerbackendtool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnablerBackendToolApplicationTests {

	@Test
	void contextLoads() {
	}

}
