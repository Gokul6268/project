$(document).ready(function() {
    // Function to fetch and display employees
    function fetchEmployees(status) {
        let url = "http://localhost:8080/api/employee/employees"; // URL for fetching employees
        if (status !== "") {
            url += "?status=" + status; // Add status filter if provided
        }

        $.ajax({
            url: url,
            type: "GET",
            success: function(employees) {
                $("#employee-table-body").empty(); // Clear previous data
                employees.forEach(function(employee) {
                    const statusText = employee.status ? "Active" : "Inactive";
                    const row = `
                        <tr>
                            <td>${employee.id}</td>
                            <td>${employee.age}</td>
                            <td>${employee.dob}</td>
                            <td>${employee.email}</td>
                            <td>${employee.name}</td>
                            <td>${employee.salary}</td>
                            <td>${statusText}</td>
                            <td>
                                <button class="btn btn-warning btn-sm edit-btn" data-id="${employee.id}">Edit</button>
                                <button class="btn btn-danger btn-sm delete-btn" data-id="${employee.id}">Delete</button>
                            </td>
                        </tr>`;
                    $("#employee-table-body").append(row); // Append each employee to the table
                });
            },
            error: function() {
                alert("Failed to fetch employees. Please try again.");
            }
        });
    }

    // Fetch all employees on page load
    fetchEmployees("");

    // Apply filter when the button is clicked
    $("#apply-filter").on("click", function() {
        const status = $("#status").val();
        fetchEmployees(status);
    });

    // Handle add employee form submission
    $("#addEmployeeForm").on("submit", function(event) {
        event.preventDefault();

        // Collect the form data
        const employeeData = {
            name: $("#name").val(),
            email: $("#email").val(),
            dob: $("#dob").val(),
            age: $("#age").val(),
            salary: $("#salary").val(),
            status: $("#status").val() === "true" // Convert string to boolean
        };

        // Send POST request to add employee
        $.ajax({
            url: "http://localhost:8080/api/employee/add", // URL for adding an employee
            type: "POST",
            contentType: "application/json",
            data: JSON.stringify(employeeData),
            success: function() {
                // Close the modal
                $("#addEmployeeModal").modal("hide");

                // Refresh employee list
                fetchEmployees("");

                // Reset the form
                $("#addEmployeeForm")[0].reset();
                alert("Employee added successfully!");
            },
            error: function() {
                alert("Failed to add employee. Please try again.");
            }
        });
    });

    // Handle Edit Button Click
    $(document).on("click", ".edit-btn", function() {
        const employeeId = $(this).data("id"); // Get the employee ID
        
        // Fetch employee details from the API using employeeId
        $.ajax({
            url: `http://localhost:8080/api/employee/employees/${employeeId}`, // URL for getting employee details
            type: "GET",
            success: function(employee) {
                // Populate the modal fields with employee data
                $("#name").val(employee.name);
                $("#email").val(employee.email);
                $("#dob").val(employee.dob);
                $("#age").val(employee.age);
                $("#salary").val(employee.salary);
                $("#status").val(employee.status.toString()); // Ensure status matches the dropdown value

                // Show the modal for editing
                $("#addEmployeeModal").modal("show");

                // Change the submit button function to update instead of add
                $("#addEmployeeForm").off("submit").on("submit", function(event) {
                    event.preventDefault();
                    const updatedEmployeeData = {
                        id: employeeId, // Send the ID for updating
                        name: $("#name").val(),
                        email: $("#email").val(),
                        dob: $("#dob").val(),
                        age: $("#age").val(),
                        salary: $("#salary").val(),
                        status: $("#status").val() === "true"
                    };

                    // Send PUT request to update employee
                    $.ajax({
                        url: `http://localhost:8080/api/employee/employees/${employeeId}`, // URL for updating
                        type: "PUT",
                        contentType: "application/json",
                        data: JSON.stringify(updatedEmployeeData),
                        success: function() {
                            $("#addEmployeeModal").modal("hide");
                            fetchEmployees(""); // Refresh the employee list
                            alert("Employee updated successfully!");
                        },
                        error: function() {
                            alert("Failed to update employee. Please try again.");
                        }
                    });
                });
            },
            error: function() {
                alert("Failed to fetch employee details."); // Log the error if the request fails
            }
        });
    });

    // Handle Delete Button Click
    $(document).on("click", ".delete-btn", function() {
        const employeeId = $(this).data("id");

        // Confirm deletion
        if (confirm("Are you sure you want to delete this employee?")) {
            $.ajax({
                url: `http://localhost:8080/api/employee/employees/${employeeId}`, // URL for deleting
                type: "DELETE",
                success: function() {
                    fetchEmployees(""); // Refresh the employee list
                    alert("Employee deleted successfully!");
                },
                error: function() {
                    alert("Failed to delete employee. Please try again.");
                }
            });
        }
    });
});
