$(document).ready(function() {
    // Array of valid credentials
    const validCredentials = [
        { username: "admin", password: "admin123" },
        { username: "user1", password: "password1" },
        { username: "user2", password: "password2" },
        { username: "user3", password: "password3" },
        { username: "user4", password: "password4" }
    ];

    $("#login-form").on("submit", function(event) {
        event.preventDefault();
        
        const username = $("#username").val();
        const password = $("#password").val();

        // Check if the entered credentials match any valid credentials
        const isValidUser = validCredentials.some(cred => cred.username === username && cred.password === password);

        if (isValidUser) {
            // Redirect to dashboard
            window.location.href = "dashboard.html";
        } else {
            // Show error message
            $("#error-message").text("Invalid username or password. Please try again.");
        }
    });
});
